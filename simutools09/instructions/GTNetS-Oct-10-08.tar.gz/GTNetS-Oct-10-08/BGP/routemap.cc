/****************************************************************************/
/*  File:            routemap.cc                                            */
/*  Author:          Sunitha Beeram                                         */
/*  Email:           sunithab@ece.gatech.edu                                */
/*  Documentation:   TBD                                                    */
/*                                                                          */
/*  Version:         1.0beta                                                */
/*                                                                          */
/*  Copyright (c) 2005 Georgia Institute of Technology                      */
/*  This program is free software; you can redistribute it and/or           */
/*  modify it under the terms of the GNU General Public License             */
/*  as published by the Free Software Foundation; either version 2          */
/*  of the License, or (at your option) any later version.                  */
/*                                                                          */
/*  This program is distributed in the hope that it will be useful,         */
/*  but WITHOUT ANY WARRANTY; without even the implied warranty of          */
/*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the           */
/*  GNU General Public License for more details.                            */
/*                                                                          */
/****************************************************************************/

#include "bgp.h"

struct _vector* BGP::route_set_vec = NULL;
struct _vector* BGP::route_match_vec = NULL;

/* New route map allocation. Please note route map's name must be
   specified. */
struct route_map *
BGP::route_map_new (char *name)
{
  struct route_map *New;

  New =  (struct route_map*)XCALLOC (MTYPE_ROUTE_MAP, sizeof (struct route_map));
  New->name = XSTRDUP (MTYPE_ROUTE_MAP_NAME, name);
  return New;
}

/* Add new name to route_map. */
struct route_map *
BGP::route_map_add (char *name)
{
  struct route_map *mmap;
  struct route_map_list *llist;

  mmap = route_map_new (name);
  llist = &route_map_master;
    
  mmap->next = NULL;
  mmap->prev = llist->tail;
  if (llist->tail)
    llist->tail->next = mmap;
  else
    llist->head = mmap;
  llist->tail = mmap;

  /* Execute hook. */
  if (route_map_master.add_hook)
    (this->*route_map_master.add_hook) (name);

  return mmap;
}

/* Route map delete from list. */
void
BGP::route_map_delete (struct route_map *mmap)
{
  struct route_map_list *llist;
  struct route_map_index *index;
  char *name;
  
  while ((index = mmap->head) != NULL)
    route_map_index_delete (index, 0);

  name = mmap->name;

  llist = &route_map_master;

  if (mmap->next)
    mmap->next->prev = mmap->prev;
  else
    llist->tail = mmap->prev;

  if (mmap->prev)
    mmap->prev->next = mmap->next;
  else
    llist->head = mmap->next;

  XFREE (MTYPE_ROUTE_MAP, mmap);

  /* Execute deletion hook. */
  if (route_map_master.delete_hook)
    (this->*route_map_master.delete_hook) (name);

  if (name)
    XFREE (MTYPE_ROUTE_MAP_NAME, name);

}

/* Lookup route map by route map name string. */
struct route_map *
BGP::route_map_lookup_by_name (char *name)
{
  struct route_map *mmap;

  for (mmap = route_map_master.head; mmap; mmap = mmap->next)
    if (strcmp (mmap->name, name) == 0)
      return mmap;
  return NULL;
}

/* Lookup route map.  If there isn't route map create one and return
   it. */
struct route_map *
BGP::route_map_get (char *name)
{
  struct route_map *mmap;

  mmap = route_map_lookup_by_name (name);
  if (mmap == NULL)
    mmap = route_map_add (name);
  return mmap;
}

/* Return route map's type string. */
char *
BGP::route_map_type_str (enum route_map_type type)
{
  switch (type)
    {
    case RMAP_PERMIT:
      return "permit";
      break;
    case RMAP_DENY:
      return "deny";
      break;
    default:
      return "";
      break;
    }
}

int
BGP::route_map_empty (struct route_map *mmap)
{
  if (mmap->head == NULL && mmap->tail == NULL)
    return 1;
  else
    return 0;
}

/* For debug. */
void
BGP::route_map_print ()
{
  struct route_map *mmap;
  struct route_map_index *index;
  struct route_map_rule *rule;

  for (mmap = route_map_master.head; mmap; mmap = mmap->next)
    for (index = mmap->head; index; index = index->next)
      {
	printf ("route-map %s %s %d\n", 
		mmap->name,
		route_map_type_str (index->type),
		index->pref);
	for (rule = index->match_list.head; rule; rule = rule->next)
	  printf (" match %s %s\n", rule->cmd->str, rule->rule_str);
	for (rule = index->set_list.head; rule; rule = rule->next)
	  printf (" set %s %s\n", rule->cmd->str, rule->rule_str);
	if (index->exitpolicy == RMAP_GOTO)
	  printf (" on-match goto %d\n", index->nextpref);
	if (index->exitpolicy == RMAP_NEXT)
	  printf (" on-match next\n");
      }
}

/* New route map allocation. Please note route map's name must be
   specified. */
struct route_map_index *
BGP::route_map_index_new ()
{
  struct route_map_index *New;

  New = (struct route_map_index*) XCALLOC (MTYPE_ROUTE_MAP_INDEX, sizeof (struct route_map_index));
  New->exitpolicy = RMAP_EXIT; /* Default to Cisco-style */
  return New;
}

/* Free route map index. */
void
BGP::route_map_index_delete (struct route_map_index *index, int notify)
{
  struct route_map_rule *rule;

  /* Free route match. */
  while ((rule = index->match_list.head) != NULL)
    route_map_rule_delete (&index->match_list, rule);

  /* Free route set. */
  while ((rule = index->set_list.head) != NULL)
    route_map_rule_delete (&index->set_list, rule);

  /* Remove index from route map list. */
  if (index->next)
    index->next->prev = index->prev;
  else
    index->mmap->tail = index->prev;

  if (index->prev)
    index->prev->next = index->next;
  else
    index->mmap->head = index->next;

    /* Execute event hook. */
  if (route_map_master.event_hook && notify)
    (this->*route_map_master.event_hook) (RMAP_EVENT_INDEX_DELETED,
				    index->mmap->name);

  XFREE (MTYPE_ROUTE_MAP_INDEX, index);
}

/* Lookup index from route map. */
struct route_map_index *
BGP::route_map_index_lookup (struct route_map *mmap, enum route_map_type type,
			int pref)
{
  struct route_map_index *index;

  for (index = mmap->head; index; index = index->next)
    if ((index->type == type || type == RMAP_ANY)
	&& index->pref == pref)
      return index;
  return NULL;
}

/* Add new index to route map. */
struct route_map_index *
BGP::route_map_index_add (struct route_map *mmap, enum route_map_type type,
		     int pref)
{
  struct route_map_index *index;
  struct route_map_index *point;

  /* Allocate new route map inex. */
  index = route_map_index_new ();
  index->mmap = mmap;
  index->type = type;
  index->pref = pref;
  
  /* Compare preference. */
  for (point = mmap->head; point; point = point->next)
    if (point->pref >= pref)
      break;

  if (mmap->head == NULL)
    {
      mmap->head = mmap->tail = index;
    }
  else if (point == NULL)
    {
      index->prev = mmap->tail;
      mmap->tail->next = index;
      mmap->tail = index;
    }
  else if (point == mmap->head)
    {
      index->next = mmap->head;
      mmap->head->prev = index;
      mmap->head = index;
    }
  else
    {
      index->next = point;
      index->prev = point->prev;
      if (point->prev)
	point->prev->next = index;
      point->prev = index;
    }

  /* Execute event hook. */
  if (route_map_master.event_hook)
    (this->*route_map_master.event_hook) (RMAP_EVENT_INDEX_ADDED,
				    mmap->name);

  return index;
}

/* Get route map index. */
struct route_map_index *
BGP::route_map_index_get (struct route_map *mmap, enum route_map_type type, 
		     int pref)
{
  struct route_map_index *index;

  index = route_map_index_lookup (mmap, RMAP_ANY, pref);
  if (index && index->type != type)
    {
      /* Delete index from route map. */
      route_map_index_delete (index, 1);
      index = NULL;
    }
  if (index == NULL)
    index = route_map_index_add (mmap, type, pref);
  return index;
}

/* New route map rule */
struct route_map_rule *
BGP::route_map_rule_new ()
{
  struct route_map_rule *New;

  New =(struct route_map_rule*) XCALLOC (MTYPE_ROUTE_MAP_RULE, sizeof (struct route_map_rule));
  return New;
}

/* Install rule command to the match list. */
void
BGP::route_map_install_match (struct route_map_rule_cmd *cmd)
{
  vector_set (route_match_vec, cmd);
}

/* Install rule command to the set list. */
void
BGP::route_map_install_set (struct route_map_rule_cmd *cmd)
{
  vector_set (route_set_vec, cmd);
}

/* Lookup rule command from match list. */
struct route_map_rule_cmd *
BGP::route_map_lookup_match (char *name)
{
  int i;
  struct route_map_rule_cmd *rule;

  for (i = 0; i < (int)vector_max (route_match_vec); i++)
    if ((rule = (struct route_map_rule_cmd *)vector_slot (route_match_vec, i)) != NULL)
      if (strcmp (rule->str, name) == 0)
	return rule;
  return NULL;
}

/* Lookup rule command from set list. */
struct route_map_rule_cmd *
BGP::route_map_lookup_set (char *name)
{
  int i;
  struct route_map_rule_cmd *rule;

  for (i = 0; i < (int)vector_max (route_set_vec); i++)
    if ((rule = (struct route_map_rule_cmd*)vector_slot (route_set_vec, i)) != NULL)
      if (strcmp (rule->str, name) == 0)
		return rule;
  return NULL;
}

/* Add match and set rule to rule list. */
void
BGP::route_map_rule_add (struct route_map_rule_list *llist,
		    struct route_map_rule *rule)
{
  rule->next = NULL;
  rule->prev = llist->tail;
  if (llist->tail)
    llist->tail->next = rule;
  else
    llist->head = rule;
  llist->tail = rule;
}

/* Delete rule from rule list. */
void
BGP::route_map_rule_delete (struct route_map_rule_list *llist,
		       struct route_map_rule *rule)
{
  if (rule->cmd->func_free)
    (this->*rule->cmd->func_free) (rule->value);

  if (rule->rule_str)
    XFREE (MTYPE_ROUTE_MAP_RULE_STR, rule->rule_str);

  if (rule->next)
    rule->next->prev = rule->prev;
  else
    llist->tail = rule->prev;
  if (rule->prev)
    rule->prev->next = rule->next;
  else
    llist->head = rule->next;

  XFREE (MTYPE_ROUTE_MAP_RULE, rule);
}

/* strcmp wrapper function which don't crush even argument is NULL. */
int
BGP::rulecmp (char *dst, char *src)
{
  if (dst == NULL)
    {
      if (src ==  NULL)
	return 0;
      else
	return 1;
    }
  else
    {
      if (src == NULL)
	return 1;
      else
	return strcmp (dst, src);
    }
  return 1;
}

/* Add match statement to route map. */
int
BGP::route_map_add_match (struct route_map_index *index, char *match_name,
		     char *match_arg)
{
  struct route_map_rule *rule;
  struct route_map_rule *next;
  struct route_map_rule_cmd *cmd;
  void *compile;
  int replaced = 0;

  /* First lookup rule for add match statement. */
  cmd = route_map_lookup_match (match_name);
  if (cmd == NULL)
    return RMAP_RULE_MISSING;

  /* Next call compile function for this match statement. */
  if (cmd->func_compile)
    {
      compile= (this->*cmd->func_compile)(match_arg);
      if (compile == NULL)
	return RMAP_COMPILE_ERROR;
    }
  else
    compile = NULL;

  /* If argument is completely same ignore it. */
  for (rule = index->match_list.head; rule; rule = next)
    {
      next = rule->next;
      if (rule->cmd == cmd)
	{	
	  route_map_rule_delete (&index->match_list, rule);
	  replaced = 1;
	}
    }

  /* Add new route map match rule. */
  rule = route_map_rule_new ();
  rule->cmd = cmd;
  rule->value = compile;
  if (match_arg)
    rule->rule_str = XSTRDUP (MTYPE_ROUTE_MAP_RULE_STR, match_arg);
  else
    rule->rule_str = NULL;

  /* Add new route match rule to linked list. */
  route_map_rule_add (&index->match_list, rule);

  /* Execute event hook. */
  if (route_map_master.event_hook)
    (this->*route_map_master.event_hook) (replaced ?
				    RMAP_EVENT_MATCH_REPLACED:
				    RMAP_EVENT_MATCH_ADDED,
				    index->mmap->name);

  return 0;
}

/* Delete specified route match rule. */
int
BGP::route_map_delete_match (struct route_map_index *index, char *match_name,
			char *match_arg)
{
  struct route_map_rule *rule;
  struct route_map_rule_cmd *cmd;

  cmd = route_map_lookup_match (match_name);
  if (cmd == NULL)
    return 1;
  
  for (rule = index->match_list.head; rule; rule = rule->next)
    if (rule->cmd == cmd && 
	(rulecmp (rule->rule_str, match_arg) == 0 || match_arg == NULL))
      {
	route_map_rule_delete (&index->match_list, rule);
	/* Execute event hook. */
	if (route_map_master.event_hook)
	  (this->*route_map_master.event_hook) (RMAP_EVENT_MATCH_DELETED,
					  index->mmap->name);
	return 0;
      }
  /* Can't find matched rule. */
  return 1;
}

/* Add route-map set statement to the route map. */
int
BGP::route_map_add_set (struct route_map_index *index, char *set_name,
		   char *set_arg)
{
  struct route_map_rule *rule;
  struct route_map_rule *next;
  struct route_map_rule_cmd *cmd;
  void *compile;
  int replaced = 0;

  cmd = route_map_lookup_set (set_name);
  if (cmd == NULL)
    return RMAP_RULE_MISSING;

  /* Next call compile function for this match statement. */
  if (cmd->func_compile)
    {
      compile= (this->*cmd->func_compile)(set_arg);
      if (compile == NULL)
	return RMAP_COMPILE_ERROR;
    }
  else
    compile = NULL;

 /* Add by WJL. if old set command of same kind exist, delete it first
    to ensure only one set command of same kind exist under a
    route_map_index. */
  for (rule = index->set_list.head; rule; rule = next)
    {
      next = rule->next;
      if (rule->cmd == cmd)
	{
	  route_map_rule_delete (&index->set_list, rule);
	  replaced = 1;
	}
    }

  /* Add new route map match rule. */
  rule = route_map_rule_new ();
  rule->cmd = cmd;
  rule->value = compile;
  if (set_arg)
    rule->rule_str = XSTRDUP (MTYPE_ROUTE_MAP_RULE_STR, set_arg);
  else
    rule->rule_str = NULL;

  /* Add new route match rule to linked list. */
  route_map_rule_add (&index->set_list, rule);

  /* Execute event hook. */
  if (route_map_master.event_hook)
    (this->*route_map_master.event_hook) (replaced ?
				    RMAP_EVENT_SET_REPLACED:
				    RMAP_EVENT_SET_ADDED,
				    index->mmap->name);
  return 0;
}

/* Delete route map set rule. */
int
BGP::route_map_delete_set (struct route_map_index *index, char *set_name,
			char *set_arg)
{
  struct route_map_rule *rule;
  struct route_map_rule_cmd *cmd;

  cmd = route_map_lookup_set (set_name);
  if (cmd == NULL)
    return 1;
  
  for (rule = index->set_list.head; rule; rule = rule->next)
    if ((rule->cmd == cmd) &&
         (rulecmp (rule->rule_str, set_arg) == 0 || set_arg == NULL))
      {
        route_map_rule_delete (&index->set_list, rule);
	/* Execute event hook. */
	if (route_map_master.event_hook)
	  (this->*route_map_master.event_hook) (RMAP_EVENT_SET_DELETED,
					  index->mmap->name);
        return 0;
      }
  /* Can't find matched rule. */
  return 1;
}

/* Apply route map's each index to the object.

   The matrix for a route-map looks like this:
   (note, this includes the description for the "NEXT"
   and "GOTO" frobs now
  
              Match   |   No Match
                      |
    permit      a     |      c
                      |
    ------------------+---------------
                      |
    deny        b     |      d
                      |
  
   a) Apply Set statements, accept route
      If NEXT is specified, goto NEXT statement
      If GOTO is specified, goto the first clause where pref > nextpref
      If nothing is specified, do as Cisco and finish
   b) If NEXT is specified, goto NEXT statement
      If nothing is specified, finally will be denied by route-map.
   c) & d)   Goto Next index
  
   If we get no matches after we've processed all updates, then the route
   is dropped too.
  
   Some notes on the new "NEXT" and "GOTO"
     on-match next    - If this clause is matched, then the set statements
                        are executed and then we drop through to the next clause
     on-match goto n  - If this clause is matched, then the set statments
                        are executed and then we goto the nth clause, or the
                        first clause greater than this. In order to ensure
                        route-maps *always* exit, you cannot jump backwards.
                        Sorry ;)
  
   We need to make sure our route-map processing matches the above
*/
route_map_result_t
BGP::route_map_apply_index (struct route_map_index *index, struct prefix *prefix,
                       route_map_object_t type, void *object)
{
  int ret = 0;
  struct route_map_rule *match;
  struct route_map_rule *sset;

  /* Check all match rule and if there is no match rule, go to the
     set statement. */
  if (! index->match_list.head)
    ret = RMAP_MATCH;
  else
    {
      for (match = index->match_list.head; match; match = match->next)
        {
          /* Try each match statement in turn, If any return
             RMAP_MATCH, go direct to set statement, otherwise, walk
             to next match statement. */ 
          ret = (this->*match->cmd->func_apply)(match->value, prefix, type, object);

          if (ret == RMAP_MATCH)
            break;
	}
    }

  /* If end of match statement, still can't get any RMAP_MATCH return,
     just return to next rout-map statement. */

  if (ret != RMAP_MATCH)
    return (route_map_result_t)ret;

  /* We get here if all match statements matched From the matrix
     above, if this is PERMIT we go on and apply the SET functions.
     If we're deny, we return indicating we matched a deny */

  /* Apply set statement to the object. */
  if (index->type == RMAP_PERMIT)
    {
      for (sset = index->set_list.head; sset; sset = sset->next)
	ret = (this->*sset->cmd->func_apply)(sset->value, prefix, type, object);

      return RMAP_MATCH;
    }
  else 
    {
      return RMAP_DENYMATCH;
    }
  /* Should not get here! */
  return RMAP_MATCH;
}

/* Apply route map to the object. */
route_map_result_t
BGP::route_map_apply (struct route_map *mmap, struct prefix *prefix, 
		 route_map_object_t type, void *object)
{
  int ret = 0;
  struct route_map_index *index;

  if (mmap == NULL)
    return RMAP_DENYMATCH;

  for (index = mmap->head; index; index = index->next)
    {
      /* Apply this index. End here if we get a RM_NOMATCH */
      ret = route_map_apply_index (index, prefix, type, object);

      if (ret == RMAP_MATCH || ret == RMAP_DENYMATCH)
        return (route_map_result_t)ret;

      if (ret != RMAP_NOMATCH)
	{
	  /* We now have to handle the NEXT and GOTO clauses */
	  if(index->exitpolicy == RMAP_EXIT)
	    return (route_map_result_t) ret;

	  if(index->exitpolicy == RMAP_GOTO)
	    {
	      /* Find the next clause to jump to */
	      struct route_map_index *next;

	      next = index->next;
	      while (next && next->pref < index->nextpref)
		{
		  index = next;
		  next = next->next;
		}
	      if (next == NULL)
		{
		  /* No clauses match! */
		  return (route_map_result_t)ret;
		}
	    }
	  /* Otherwise, we fall through as it was a NEXT */
	}
    }
  /* Finally route-map does not match at all. */
  return RMAP_DENYMATCH;
}

void
BGP::route_map_add_hook (void (BGP::*func) (char *))
{
  route_map_master.add_hook = func;
}

void
BGP::route_map_delete_hook (void (BGP::*func) (char *))
{
  route_map_master.delete_hook = func;
}

void
BGP::route_map_event_hook (void (BGP::*func) (route_map_event_t, char *))
{
  route_map_master.event_hook = func;
}

void
BGP::route_map_init ()
{
  /* Make vector for match and set. */
  route_match_vec = vector_init (1);
  route_set_vec = vector_init (1);
}

/* VTY related functions. */
DEFUN (route_map,
       route_map_cmd,
       "route-map WORD (deny|permit) <1-65535>",
       "Create route-map or enter route-map command mode\n"
       "Route map tag\n"
       "Route map denies set operations\n"
       "Route map permits set operations\n"
       "Sequence to insert to/delete from existing route-map entry\n")
{
  int permit;
  unsigned long pref;
  struct route_map *mmap;
  struct route_map_index *index;
  char *endptr = NULL;

  /* Permit check. */
  if (strncmp (argv[1], "permit", strlen (argv[1])) == 0)
    permit = RMAP_PERMIT;
  else if (strncmp (argv[1], "deny", strlen (argv[1])) == 0)
    permit = RMAP_DENY;
  else
    {
      vty_out (vty, "the third field must be [permit|deny]%s", VTY_NEWLINE);
      return CMD_WARNING;
    }

  /* Preference check. */
  pref = strtoul (argv[2], &endptr, 10);
  if (pref == ULONG_MAX || *endptr != '\0')
    {
      vty_out (vty, "the fourth field must be positive integer%s",
	       VTY_NEWLINE);
      return CMD_WARNING;
    }
  if (pref == 0 || pref > 65535)
    {
      vty_out (vty, "the fourth field must be <1-65535>%s", VTY_NEWLINE);
      return CMD_WARNING;
    }

  /* Get route map. */
  mmap = route_map_get (argv[0]);
  index = route_map_index_get (mmap, (route_map_type)permit, pref);

  vty->index = index;
  vty->node = RMAP_NODE;
  return CMD_SUCCESS;
}

DEFUN (no_route_map_all,
       no_route_map_all_cmd,
       "no route-map WORD",
       NO_STR
       "Create route-map or enter route-map command mode\n"
       "Route map tag\n")
{
  struct route_map *mmap;

  mmap = route_map_lookup_by_name (argv[0]);
  if (mmap == NULL)
    {
      vty_out (vty, "%% Could not find route-map %s%s",
	       argv[0], VTY_NEWLINE);
      return CMD_WARNING;
    }

  route_map_delete (mmap);

  return CMD_SUCCESS;
}

DEFUN (no_route_map,
       no_route_map_cmd,
       "no route-map WORD (deny|permit) <1-65535>",
       NO_STR
       "Create route-map or enter route-map command mode\n"
       "Route map tag\n"
       "Route map denies set operations\n"
       "Route map permits set operations\n"
       "Sequence to insert to/delete from existing route-map entry\n")
{
  int permit;
  unsigned long pref;
  struct route_map *mmap;
  struct route_map_index *index;
  char *endptr = NULL;

  /* Permit check. */
  if (strncmp (argv[1], "permit", strlen (argv[1])) == 0)
    permit = RMAP_PERMIT;
  else if (strncmp (argv[1], "deny", strlen (argv[1])) == 0)
    permit = RMAP_DENY;
  else
    {
      vty_out (vty, "the third field must be [permit|deny]%s", VTY_NEWLINE);
      return CMD_WARNING;
    }

  /* Preference. */
  pref = strtoul (argv[2], &endptr, 10);
  if (pref == ULONG_MAX || *endptr != '\0')
    {
      vty_out (vty, "the fourth field must be positive integer%s",
	       VTY_NEWLINE);
      return CMD_WARNING;
    }
  if (pref == 0 || pref > 65535)
    {
      vty_out (vty, "the fourth field must be <1-65535>%s", VTY_NEWLINE);
      return CMD_WARNING;
    }

  /* Existence check. */
 mmap = route_map_lookup_by_name (argv[0]);
  if (mmap == NULL)
    {
      vty_out (vty, "%% Could not find route-map %s%s",
	       argv[0], VTY_NEWLINE);
      return CMD_WARNING;
    }

  /* Lookup route map index. */
  index = route_map_index_lookup (mmap, (route_map_type)permit, pref);
  if (index == NULL)
    {
      vty_out (vty, "%% Could not find route-map entry %s %s%s", 
	       argv[0], argv[2], VTY_NEWLINE);
      return CMD_WARNING;
    }

  /* Delete index from route map. */
  route_map_index_delete (index, 1);

  /* If this route rule is the last one, delete route map itself. */
  if (route_map_empty (mmap))
    route_map_delete (mmap);

  return CMD_SUCCESS;
}

DEFUN (rmap_onmatch_next,
       rmap_onmatch_next_cmd,
       "on-match next",
       "Exit policy on matches\n"
       "Next clause\n")
{
  struct route_map_index *index;

  index = (struct route_map_index*)vty->index;

  if (index)
    index->exitpolicy = RMAP_NEXT;

  return CMD_SUCCESS;
}

DEFUN (no_rmap_onmatch_next,
       no_rmap_onmatch_next_cmd,
       "no on-match next",
       NO_STR
       "Exit policy on matches\n"
       "Next clause\n")
{
  struct route_map_index *index;

  index = (struct route_map_index*)vty->index;
  
  if (index)
    index->exitpolicy = RMAP_EXIT;

  return CMD_SUCCESS;
}

DEFUN (rmap_onmatch_goto,
       rmap_onmatch_goto_cmd,
       "on-match goto <1-65535>",
       "Exit policy on matches\n"
       "Goto Clause number\n"
       "Number\n")
{
  struct route_map_index *index;
  int d = 0;

  if (argv[0])
    d = atoi(argv[0]);

  index = (struct route_map_index*)vty->index;
  if (index)
    {
      if (d <= index->pref)
	{
	  /* Can't allow you to do that, Dave */
	  vty_out (vty, "can't jump backwards in route-maps%s", 
		   VTY_NEWLINE);
	  return CMD_WARNING;
	}
      else
	{
	  index->exitpolicy = RMAP_GOTO;
	  index->nextpref = d;
	}
    }
  return CMD_SUCCESS;
}

DEFUN (no_rmap_onmatch_goto,
       no_rmap_onmatch_goto_cmd,
       "no on-match goto",
       NO_STR
       "Exit policy on matches\n"
       "Next clause\n")
{
  struct route_map_index *index;

  index = (struct route_map_index*)vty->index;

  if (index)
    index->exitpolicy = RMAP_EXIT;
  
  return CMD_SUCCESS;
}

/* Configuration write function. */
int
BGP::route_map_config_write (struct vty *vty)
{
  struct route_map *mmap;
  struct route_map_index *index;
  struct route_map_rule *rule;
  int first = 1;
  int write = 0;

  for (mmap = route_map_master.head; mmap; mmap = mmap->next)
    for (index = mmap->head; index; index = index->next)
      {
	if (!first)
	  vty_out (vty, "!%s", VTY_NEWLINE);
	else
	  first = 0;

	vty_out (vty, "route-map %s %s %d%s", 
		 mmap->name,
		 route_map_type_str (index->type),
		 index->pref, VTY_NEWLINE);

	for (rule = index->match_list.head; rule; rule = rule->next)
	  vty_out (vty, " match %s %s%s", rule->cmd->str, 
		   rule->rule_str ? rule->rule_str : "",
		   VTY_NEWLINE);

	for (rule = index->set_list.head; rule; rule = rule->next)
	  vty_out (vty, " set %s %s%s", rule->cmd->str,
		   rule->rule_str ? rule->rule_str : "",
		   VTY_NEWLINE);
	if (index->exitpolicy == RMAP_GOTO)
	  vty_out (vty, " on-match goto %d%s", index->nextpref,
		   VTY_NEWLINE);
	if (index->exitpolicy == RMAP_NEXT)
	  vty_out (vty," on-match next%s", VTY_NEWLINE);
	
	write++;
      }
  return write;
}

/* Route map node structure. */
struct cmd_node BGP::rmap_node =
{
  RMAP_NODE,
  "%s(config-route-map)# ",
  1
};

/* Initialization of route map vector. */
void
BGP::route_map_init_vty ()
{
  /* Install route map top node. */
  install_node (&rmap_node, &BGP::route_map_config_write);

 /* Install route map commands. */
  //install_default (RMAP_NODE);
  install_element (CONFIG_NODE, &route_map_cmd);
  install_element (CONFIG_NODE, &neighbor_send_community_cmd);
  install_element (CONFIG_NODE, &no_route_map_cmd);
  install_element (CONFIG_NODE, &no_route_map_all_cmd);

  /* Install the on-match stuff */
  install_element (RMAP_NODE, &route_map_cmd);
  install_element (RMAP_NODE, &rmap_onmatch_next_cmd);
  install_element (RMAP_NODE, &no_rmap_onmatch_next_cmd);
  install_element (RMAP_NODE, &rmap_onmatch_goto_cmd);
  install_element (RMAP_NODE, &no_rmap_onmatch_goto_cmd);

}
