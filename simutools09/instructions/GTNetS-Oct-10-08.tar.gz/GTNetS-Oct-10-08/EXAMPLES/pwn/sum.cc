#include <iostream>
#include <stdlib.h>
#include <stdio.h>

char line[255];
unsigned long tot = 0;
unsigned long cnt = 0;

using namespace std;

int main()
{
  FILE* f = fopen("zzz.jeffay3000", "r");
  if (!f) exit(1);
  while(fgets(line, sizeof(line), f) != NULL)
    {
      if(0)printf("Line %s", line);
      cnt++;
      tot += atol(&line[9]);
    }
  cout << "Average " << (double)tot / (double)cnt
       << " cnt " << cnt << endl;
}
